javascript-clash-of-clans
=========================

Use this is to test your layout and plan your attacks while playing clash of clans!

Go to http://c9.io and sign in with your github.

create new workspace from url

run

npm install socket.io

Oh and you are going to need to read this [over at cloud9 support][1] and the comments there-in

[1]: http://support.cloud9ide.com/entries/21285626-How-do-I-push-my-Cloud9-project-to-GitHub "How do I push my Cloud 9 project to GitHub"



